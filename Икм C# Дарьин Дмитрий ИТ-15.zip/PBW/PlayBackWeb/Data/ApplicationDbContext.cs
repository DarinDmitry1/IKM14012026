﻿using Microsoft.EntityFrameworkCore;
using PlayBackWeb.Models;

namespace PlayBackWeb.Data
{ 
    /// <summary>
    /// Контекст базы данных приложения
    /// </summary>
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Genre> Genres { get; set; }
        public DbSet<Band> Bands { get; set; }
        public DbSet<Playback> Playbacks { get; set; }
    }
    
}