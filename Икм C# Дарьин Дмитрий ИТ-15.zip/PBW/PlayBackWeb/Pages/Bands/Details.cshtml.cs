using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PlayBackWeb.Data;
using PlayBackWeb.Models;

namespace PlayBackWeb.Pages.Bands
{
    /// <summary>
    /// PageModel ��� ��������� ������� ����������� ������
    /// </summary>
    public class DetailsModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public DetailsModel(ApplicationDbContext context) => _context = context;

        public Band Band { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Band = await _context.Bands
                .Include(b => b.Genre)
                .FirstOrDefaultAsync(b => b.Id == id);
            if (Band == null) return NotFound();
            return Page();
        }
    }
}