using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using PlayBackWeb.Data;
using PlayBackWeb.Models;

namespace PlayBackWeb.Pages.Bands
{
    /// <summary>
    /// PageModel ��� �������� ����������� ������
    /// </summary>
    public class CreateModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public CreateModel(ApplicationDbContext context) => _context = context;

        [BindProperty]
        public Band Band { get; set; } = default!;

        /// <summary>
        /// ������ ������ ��� ������
        /// </summary>
        public SelectList GenreList { get; set; } = default!;

        public void OnGet()
        {
            GenreList = new SelectList(_context.Genres, "Id", "Name");
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                GenreList = new SelectList(_context.Genres, "Id", "Name");
                return Page();
            }

            _context.Bands.Add(Band);
            await _context.SaveChangesAsync();
            return RedirectToPage("Index");
        }
    }
}