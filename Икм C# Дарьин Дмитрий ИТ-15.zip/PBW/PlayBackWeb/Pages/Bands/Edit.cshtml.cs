using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PlayBackWeb.Data;
using PlayBackWeb.Models;

namespace PlayBackWeb.Pages.Bands
{
    /// <summary>
    /// PageModel ��� �������������� ����������� ������
    /// </summary>
    public class EditModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public EditModel(ApplicationDbContext context) => _context = context;

        [BindProperty]
        public Band Band { get; set; } = default!;

        public SelectList GenreList { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Band = await _context.Bands.FindAsync(id);
            if (Band == null) return NotFound();

            GenreList = new SelectList(_context.Genres, "Id", "Name", Band.GenreId);
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                GenreList = new SelectList(_context.Genres, "Id", "Name", Band.GenreId);
                return Page();
            }

            _context.Attach(Band).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Bands.Any(e => e.Id == Band.Id)) return NotFound();
                else throw;
            }

            return RedirectToPage("Index");
        }
    }
}