using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PlayBackWeb.Data;
using PlayBackWeb.Models;

namespace PlayBackWeb.Pages.Genres
{
    /// <summary>
    /// PageModel ��� �������������� �����
    /// </summary>
    public class EditModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public EditModel(ApplicationDbContext context) => _context = context;

        [BindProperty]
        public Genre Genre { get; set; } = default!;

        /// <summary>
        /// �������� ����� ��� ��������������
        /// </summary>
        public async Task<IActionResult> OnGetAsync(int id)
        {
            Genre = await _context.Genres.FindAsync(id);
            if (Genre == null) return NotFound();
            return Page();
        }

        /// <summary>
        /// ���������� ���������
        /// </summary>
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();

            _context.Attach(Genre).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Genres.Any(e => e.Id == Genre.Id)) return NotFound();
                else throw;
            }

            return RedirectToPage("Index");
        }
    }
}