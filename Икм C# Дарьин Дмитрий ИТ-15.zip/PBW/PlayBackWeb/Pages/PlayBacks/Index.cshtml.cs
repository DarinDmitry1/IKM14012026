using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PlayBackWeb.Data;
using PlayBackWeb.Models;

namespace PlayBackWeb.Pages.Playbacks
{
    /// <summary>
    /// PageModel ��� ����������� ������ ���������
    /// </summary>
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context) => _context = context;

        public IList<Playback> Playbacks { get; set; } = default!;

        public async Task OnGetAsync()
        {
            Playbacks = await _context.Playbacks.Include(p => p.Band).ToListAsync();
        }
    }
}