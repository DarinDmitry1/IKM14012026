using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PlayBackWeb.Data;
using PlayBackWeb.Models;

namespace PlayBackWeb.Pages.Playbacks
{
    /// <summary>
    /// PageModel ��� �������������� ��������
    /// </summary>
    public class EditModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public EditModel(ApplicationDbContext context) => _context = context;

        [BindProperty]
        public Playback Playback { get; set; } = default!;

        public SelectList BandList { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Playback = await _context.Playbacks.FindAsync(id);
            if (Playback == null) return NotFound();

            BandList = new SelectList(_context.Bands, "Id", "Name", Playback.BandId);
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                BandList = new SelectList(_context.Bands, "Id", "Name", Playback.BandId);
                return Page();
            }

            _context.Attach(Playback).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Playbacks.Any(e => e.Id == Playback.Id)) return NotFound();
                else throw;
            }

            return RedirectToPage("Index");
        }
    }
}
