using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using PlayBackWeb.Data;
using PlayBackWeb.Models;

namespace PlayBackWeb.Pages.Playbacks
{
    /// <summary>
    /// PageModel ��� �������� ������ ��������
    /// </summary>
    public class CreateModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public CreateModel(ApplicationDbContext context) => _context = context;

        [BindProperty]
        public Playback Playback { get; set; } = default!;

        public SelectList BandList { get; set; } = default!;

        public void OnGet()
        {
            BandList = new SelectList(_context.Bands, "Id", "Name");
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                BandList = new SelectList(_context.Bands, "Id", "Name");
                return Page();
            }

            _context.Playbacks.Add(Playback);
            await _context.SaveChangesAsync();
            return RedirectToPage("Index");
        }
    }
}