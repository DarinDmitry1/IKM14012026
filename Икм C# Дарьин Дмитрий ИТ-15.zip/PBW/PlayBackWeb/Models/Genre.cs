﻿using System.ComponentModel.DataAnnotations;

namespace PlayBackWeb.Models
{
    /// <summary>
    /// Музыкальный жанр
    /// </summary>
    public class Genre
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Название жанра")]
        public string Name { get; set; }

        [StringLength(300)]
        [Display(Name = "Описание")]
        public string? Description { get; set; }
    }
}
