﻿using System.ComponentModel.DataAnnotations;

namespace PlayBackWeb.Models
{
    /// <summary>
    /// Плейбек (музыкальная дорожка)
    /// </summary>
    public class Playback
    {
        public int Id { get; set; }

        [Required]
        [StringLength(200)]
        [Display(Name = "Название плейбека")]
        public string Title { get; set; }

        [Range(10, 3600)]
        [Display(Name = "Длительность (сек)")]
        public int DurationSeconds { get; set; }

        [Range(0, 100000)]
        [Display(Name = "Цена")]
        public decimal Price { get; set; }

        /// <summary>
        /// Идентификатор группы
        /// </summary>
        [Display(Name = "Группа")]
        public int BandId { get; set; }

        /// <summary>
        /// Группа-исполнитель
        /// </summary>
        public Band? Band { get; set; }
    }
}