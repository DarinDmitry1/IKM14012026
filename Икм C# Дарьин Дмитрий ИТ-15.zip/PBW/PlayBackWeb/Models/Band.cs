﻿using System.ComponentModel.DataAnnotations;

namespace PlayBackWeb.Models
{
    /// <summary>
    /// Музыкальная группа
    /// </summary>
    public class Band
    {
        public int Id { get; set; }

        [Required]
        [StringLength(150)]
        [Display(Name = "Название группы")]
        public string Name { get; set; }

        [Range(1, 20)]
        [Display(Name = "Количество участников")]
        public int MembersCount { get; set; }

        /// <summary>
        /// Идентификатор жанра
        /// </summary>
        [Display(Name = "Жанр")]
        public int GenreId { get; set; }

        /// <summary>
        /// Жанр группы
        /// </summary>
        public Genre? Genre { get; set; }
    }
}